package acme_bankclient;

public class InvalidInputException extends Exception
{
	
}
