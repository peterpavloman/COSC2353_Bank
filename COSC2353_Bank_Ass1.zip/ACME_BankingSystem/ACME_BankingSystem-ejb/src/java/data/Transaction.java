/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.math.BigDecimal;

/**
 *
 * @author narks
 */
public class Transaction{
	private int		id, savingID;
	private BigDecimal mAmount;
	private String	description;

	public Transaction(int savingID, BigDecimal aAmount, String description){
		this(-1, savingID, aAmount, description);
	}

	public Transaction(int id, int savingID, BigDecimal aAmount, String description){
		this.id			=id;
		this.savingID	=savingID;
		this.mAmount		=aAmount;
		this.description=description;
	}

	public int getID(){ return id; }
	public void setID(int id){ this.id= id; }

	public int getSavingID(){ return savingID; }
	public void setSavingID(int savingID){ this.savingID= savingID; }

	public BigDecimal getAmount(){ return mAmount; }
	public void setAmount(BigDecimal aAmount){ mAmount = aAmount; }

	public String getDescription(){ return description; }
	public void setDescription(String description){ this.description=description; }
}
